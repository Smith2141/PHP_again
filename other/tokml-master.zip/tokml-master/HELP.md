tokml

usage:

    tokml file.geojson
    tokml < file.geojson > file.kml

    --simplestyle
      enable simplestyle icon translation
    --name
      property for <name>
    --description
      property for <description>
    --documentName
      property for document <name>
    --documentDescription
      property for document <description>
