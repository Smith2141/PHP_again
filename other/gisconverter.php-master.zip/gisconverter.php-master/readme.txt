gisconverter.php is a php library to convert vector geometries between
different formats. Currently, WKT, GeoJSON, KML and GPX formats are supported.
See example.php for a documentation of how to use the library

gisconverter.php needs php at least 5.3

gisconverter.php is available under modified bsd license. See COPYING.txt for
more informations.
